package com.example.a0504.ui.address

import android.R
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.a0504.databinding.FragmentAddressBinding
import com.example.a0504.ui.add.MyDBHelper


class AddressFragment : Fragment() , OnClickListener{
    //Fragment Setting
    private var _binding: FragmentAddressBinding? = null
    private val binding get() = _binding!!

    //Spinner Declare
    private lateinit var spinner: Spinner

    //db
    val dataList = ArrayList<String>()
    val dataList2 = ArrayList<String>()

    //Object Declare
    private lateinit var btnclean:Button
    private lateinit var btnenter:Button
    private lateinit var text1:TextView
    private lateinit var show:TextView
    private var tin = arrayListOf<String>()
    private var bin:Int = 0
    lateinit var selectedItem : String

    //Is Record? Check
    private var cRecord =0

    //Main Function
    //Inheritance Fragment call inCreateView
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        //Spinner
        val fragmentContext: Context = requireContext()

        //binding
        _binding = FragmentAddressBinding.inflate(inflater, container, false)

        //Connect
        btnclean = binding.clean
        btnenter = binding.count
        text1 = binding.t1
        show = binding.tshow

        //db
        val dbFILE = "Call.db"
        val dbTable = "call"
        var MyDB: SQLiteDatabase
        val friDbHp = MyDBHelper(context, dbFILE, null, 1)

        //DB Setting
        friDbHp.sCreateTableCommand = "CREATE TABLE " + dbTable + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "address TEXT)"
        MyDB = friDbHp.writableDatabase

        //Store the data from the "name" field of the database into the dataList.
        //Data from the "address" field of the database into the dataList.
        val query = "SELECT * FROM $dbTable"
        val cursor: Cursor = MyDB.rawQuery(query, null)
        if (cursor.moveToFirst()) {
            do {
                val data = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                dataList.add(data)
                val data2 = cursor.getString(cursor.getColumnIndexOrThrow("address"))
                dataList2.add(data2)
            } while (cursor.moveToNext())
        }
        cursor.close()
        MyDB.close()

        //Check if the database is empty.
        //If it is not, then use an adapter to bind the Spinner
        //And update its options with the dataList.
        if(dataList.isNotEmpty()){
            //Spinner
            spinner = binding.spinner
            val adapter = ArrayAdapter(fragmentContext, R.layout.simple_spinner_item, dataList)
            adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }else{
            val tmpArray = ArrayList<String>()
            tmpArray.add("")
            spinner = binding.spinner
            val adapter = ArrayAdapter(fragmentContext, R.layout.simple_spinner_item, tmpArray)
            adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
        }

        //Listener
        btnclean.setOnClickListener(fClean)
        btnenter.setOnClickListener(fEnter)

        //Spinner Listener
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                //Spinner選擇的內容(Sting)
                selectedItem = parent.getItemAtPosition(position).toString()
                //取得符合DB name 的 Address 數值，等待修改
                if(dataList.isNotEmpty()) {
                    val addresstmp = dataList2[dataList.indexOf(selectedItem)]
                    binding.EditText.setText(addresstmp)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {
                // 當沒有選擇任何選項時觸發的處理
            }
        }

        //紀錄按鈕
        binding.btnRecord.setOnClickListener {
            if(dataList.isNotEmpty()){
                cRecord = 1
                MyDB = friDbHp.writableDatabase
                val newRow = ContentValues()
                val tmpSpinnerName : String = binding.spinner.selectedItem.toString()
                newRow.put("name",tmpSpinnerName)
                //操作優化 與 美觀除錯
                if(binding.tshow.text.toString() != "") {
                    //如果不為空則記錄計算結果
                    newRow.put("Address", binding.tshow.text.toString())
                }else{
                    //如果計算結果為空，則紀錄輸入欄位內的資料
                    newRow.put("Address", binding.t1.text.toString())
                }
                MyDB.update(dbTable, newRow,"name = '${tmpSpinnerName}' ", null)
                MyDB.close()
                //ArrayList 修正
                dataList2[dataList.indexOf(tmpSpinnerName)] = binding.tshow.text.toString()
                //校正EditText顯示
                if(binding.tshow.text.toString() != "") {
                    binding.EditText.setText(binding.tshow.text.toString())
                }else{
                    binding.EditText.setText(binding.t1.text.toString())
                }
            }else{
                binding.EditText.setText("請先擁有一筆資料！")
            }
        }

        //修改按鈕
        binding.btnModify2.setOnClickListener {
            MyDB = friDbHp.writableDatabase
            val newRow = ContentValues()
            val tmpSpinnerName : String = binding.spinner.selectedItem.toString()
            // 除錯 修改tmp 顯示
            if(dataList.isNotEmpty()) {
                dataList2[dataList.indexOf(tmpSpinnerName)] = binding.EditText.text.toString()
            }
            //DB 操作
            newRow.put("name", tmpSpinnerName)
            newRow.put("address", binding.EditText.text.toString())
            MyDB.update(dbTable, newRow,"name = '${tmpSpinnerName}' ", null)
            MyDB.close()
        }

        //刪除按鈕
        binding.btnDeleted2.setOnClickListener {
            if(dataList.isNotEmpty()) {
                val tmpSpinnerName: String = binding.spinner.selectedItem.toString()
                val tmpAddressName: String = dataList2[dataList.indexOf(tmpSpinnerName)]
                MyDB = friDbHp.writableDatabase
                MyDB.delete(dbTable, "name = '${tmpSpinnerName}'", null)
                MyDB.close()
                //ArrayList removed
                dataList.remove(tmpSpinnerName)
                dataList2.remove(tmpAddressName)
                //Update spinner
                val adapter = ArrayAdapter(fragmentContext, R.layout.simple_spinner_item, dataList)
                adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
                //Remove EditText show
                binding.EditText.setText("")
            }else{
                binding.EditText.setText("")
            }
        }

        //統一監聽設定
        fun btnListenerSetting(){
            //輩分按鈕
            binding.btn1.setOnClickListener(this)
            binding.btn2.setOnClickListener(this)
            binding.btn3.setOnClickListener(this)
            binding.btn4.setOnClickListener(this)
            binding.btn5.setOnClickListener(this)
            binding.btn6.setOnClickListener(this)
            binding.btn7.setOnClickListener(this)
            binding.btn8.setOnClickListener(this)
            binding.btn9.setOnClickListener(this)
            binding.btn10.setOnClickListener(this)
            binding.btn11.setOnClickListener(this)
            binding.btn12.setOnClickListener(this)
        }
        btnListenerSetting()

        return binding.root
    }
    //關閉葉面
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    //清空顯示
    private var fClean = OnClickListener {
        text1.text = ""
        show.text = ""
        tin.clear()
    }

    //統一監聽呼叫(使用Listener)
    private var fEnter = OnClickListener {
        calculate()
    }

    //統一按鈕活動
    override fun onClick(v: View?) {
        //確認按鈕不為空值(除錯)
        if (v != null) {
            //第二輪計算，繼承上一輪資料
            if(binding.tshow.text != ""){
                tin.clear()//清空一輪資料
                binding.t1.text = binding.tshow.text
                tin += binding.tshow.text.toString()
            }else{//除錯,否則預設值(第一次計算)
                binding.tshow.text = ""
            }
            //Btn 名稱取得
            when(v.id){
                binding.btn1.id -> tin += binding.btn1.text.toString()
                binding.btn2.id -> tin += binding.btn2.text.toString()
                binding.btn3.id -> tin += binding.btn3.text.toString()
                binding.btn4.id -> tin += binding.btn4.text.toString()
                binding.btn5.id -> tin += binding.btn5.text.toString()
                binding.btn6.id -> tin += binding.btn6.text.toString()
                binding.btn7.id -> tin += binding.btn7.text.toString()
                binding.btn8.id -> tin += binding.btn8.text.toString()
                binding.btn9.id -> tin += binding.btn9.text.toString()
                binding.btn10.id -> tin += binding.btn10.text.toString()
                binding.btn11.id -> tin += binding.btn11.text.toString()
                binding.btn12.id -> tin += binding.btn12.text.toString()
            }
            show(bin)
        }
    }

    //輩分計算
    private fun calculate(){
        show.text = ""
        //只有一個輸入，除錯
        if(tin.size != 1 ) {
            //text_in檢測，兩兩比較，比較完成取代後方
            for (j in 0 until tin.size - 1) {
                //第一個比較
                when (tin[j]) {
                    "爸爸" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "媽媽" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "兄弟" -> {
                                show.text = "舅叔"
                                tin[j + 1] = "舅叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "祖父" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin += 1
                            }
                            "丈夫" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "妻子" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "兒子" ->{
                                show.text = "兄弟"
                                tin[j + 1] = "兄弟"
                            }
                            "女兒" ->{
                                show.text = "姊妹"
                                tin[j + 1] = "姊妹"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "媽媽" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                            }
                            "兄弟" -> {
                                show.text = "舅舅"
                                tin[j + 1] = "舅舅"
                            }
                            "姊妹" -> {
                                show.text = "阿姨"
                                tin[j + 1] = "阿姨"
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 1
                            }
                            "丈夫" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "妻子" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "兒子" ->{
                                show.text = "兄弟"
                                tin[j + 1] = "兄弟"
                            }
                            "女兒" ->{
                                show.text = "姊妹"
                                tin[j + 1] = "姊妹"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "兄弟","姊妹" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "媽媽" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "兄弟" -> {
                                show.text = "兄弟"
                                tin[j + 1] = "兄弟"
                            }
                            "姊妹" -> {
                                show.text = "姊妹"
                                tin[j + 1] = "姊妹"
                            }
                            "祖父" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "丈夫" -> {
                                when(tin[j]){
                                    "兄弟" ->{
                                        show.text = "兄夫弟婿"
                                        tin[j + 1] = "兄夫弟婿"
                                    }
                                    "姊妹" -> {
                                        show.text = "姊夫妹夫"
                                        tin[j + 1] = "姊夫妹夫"
                                    }
                                }
                            }
                            "妻子" -> {
                                when(tin[j]){
                                    "兄弟" ->{
                                        show.text = "兄嫂弟媳"
                                        tin[j + 1] = "兄嫂弟媳"
                                    }
                                    "姊妹" -> {
                                        show.text = "姊嫂妹媳"
                                        tin[j + 1] = "姊嫂妹媳"
                                    }
                                }
                            }
                            "兒子" ->{
                                show.text = "姪子"
                                tin[j + 1] = "姪子"
                            }
                            "女兒" ->{
                                show.text = "姪女"
                                tin[j + 1] = "姪女"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "丈夫" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "公公"
                                tin[j + 1] = "公公"
                            }
                            "媽媽" -> {
                                show.text = "婆婆"
                                tin[j + 1] = "婆婆"
                            }
                            "兄弟" -> {
                                show.text = "伯叔"
                                tin[j + 1] = "伯叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "丈夫","妻子" -> {
                                show.text = "自己"
                            }
                            "兒子" ->{
                                show.text = "兒子"
                                tin[j + 1] = "兒子"
                            }
                            "女兒" ->{
                                show.text = "女兒"
                                tin[j + 1] = "女兒"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "妻子" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "岳父"
                                tin[j + 1] = "岳父"
                            }
                            "媽媽" -> {
                                show.text = "岳母"
                                tin[j + 1] = "岳母"
                            }
                            "兄弟" -> {
                                show.text = "舅子"
                                tin[j + 1] = "舅子"
                            }
                            "姊妹" -> {
                                show.text = "姨子"
                                tin[j + 1] = "姨子"
                            }
                            "丈夫","妻子" -> {
                                show.text = "自己"
                            }
                            "兒子" ->{
                                show.text = "兒子"
                                tin[j + 1] = "兒子"
                            }
                            "女兒" ->{
                                show.text = "女兒"
                                tin[j + 1] = "女兒"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "祖父" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                show.text = "伯叔公"
                                tin[j + 1] = "伯叔公"
                            }
                            "姊妹" -> {
                                show.text = "姑婆"
                                tin[j + 1] = "姑婆"
                            }
                            "爺爺" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 2
                            }
                            "奶奶" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "妻子" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "兒子" ->{
                                show.text = "爸爸/叔伯"
                                tin[j + 1] = "爸爸/叔伯"
                            }
                            "女兒" ->{
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "祖母" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                show.text = "舅公"
                                tin[j + 1] = "舅公"
                            }
                            "姊妹" -> {
                                show.text = "姨婆"
                                tin[j + 1] = "姨婆"
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 2
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "妻子" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }"兒子" ->{
                                show.text = "爸爸/叔伯"
                                tin[j + 1] = "爸爸/叔伯"
                            }
                            "女兒" ->{
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "外祖父","外祖母" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                when(tin[j + 1]){
                                    "外祖父" -> {
                                        show.text = "伯叔公"
                                        tin[j + 1] = "伯叔公"
                                    }
                                    "外祖母" ->{
                                        show.text = "舅公"
                                        tin[j + 1] = "舅公"
                                    }
                                }
                            }
                            "姊妹" -> {
                                when(tin[j + 1]){
                                    "外祖父" -> {
                                        show.text = "姑婆"
                                        tin[j + 1] = "姑婆"
                                    }
                                    "外祖母" ->{
                                        show.text = "姨公"
                                        tin[j + 1] = "姨公"
                                    }
                                }
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 2
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                            }
                            "妻子" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                            }
                            "兒子" ->{
                                show.text = "舅舅"
                                tin[j + 1] = "舅舅"
                            }
                            "女兒" ->{
                                show.text = "阿姨"
                                tin[j + 1] = "阿姨"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "兒子","女兒" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸","媽媽" -> {
                                show.text = "自己"
                                tin[j + 1] = "自己"
                            }
                            "兄弟" -> {
                                show.text = "兒子"
                                tin[j + 1] = "兒子"
                            }
                            "姊妹" -> {
                                show.text = "女兒"
                                tin[j + 1] = "女兒"
                            }
                            "祖父" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "祖母" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "丈夫" ->{
                                show.text = "兒女婿"
                                tin[j + 1] = "兒女婿"
                            }
                            "妻子" -> {
                                show.text = "兒女媳"
                                tin[j + 1] = "兒女媳"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "姑姑" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "媽媽" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "兄弟" -> {
                                show.text = "伯叔"
                                tin[j + 1] = "伯叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "兒子" -> {
                                show.text = "表兄弟"
                                tin[j + 1] = "表兄弟"
                            }
                            "女兒" -> {
                                show.text = "表姊妹"
                                tin[j + 1] = "表姊妹"
                            }
                            "丈夫" -> {
                                show.text = "姑丈"
                                tin[j + 1] = "姑丈"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "伯叔" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "媽媽" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "兄弟" -> {
                                show.text = "伯叔"
                                tin[j + 1] = "伯叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "兒子" -> {
                                show.text = "堂兄弟"
                                tin[j + 1] = "堂兄弟"
                            }
                            "女兒" -> {
                                show.text = "堂姊妹"
                                tin[j + 1] = "堂姊妹"
                            }
                            "妻子" -> {
                                show.text = "嬸嬸"
                                tin[j + 1] = "嬸嬸"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    else -> {
                        show.text = "超出計算"
                    }
                }
            }
        }else{
            show.text = tin[0]
        }
        tin.clear()//清空判別
        show(bin)
    }

    //顯示設定
    private fun show(bin:Int){
        //清除暫存列
        text1.text = ""
        //超級加輩
        if (bin != 0){
            for(k in 1 .. bin){
                show.text = "曾".plus(show.text)
            }
        }
        //重置,加輩器
        this.bin = 0
        //除錯,空陣列
        if (tin.size != 0){
            text1.text = tin[0]
            //除錯,小於1陣列
            if (tin.size > 1){
                for (i in 1 until tin.size){
                    text1.text = text1.text.toString().plus(" 的 ").plus(tin[i])
                }
            }else{
                //tin = 1
            }
        }else{
            //空陣列Do nothing
        }
    }

    /*
    //多回傳
    data class Person(val name: String, val count: Int)
    //字串重複,檢驗(GPT)
    private fun checkAndRemoveDuplicates(input: String, target: String): Person {
        var count = 0
        var result = input

        while (result.contains(target)) {
            count++
            result = result.replaceFirst(target, "")
        }

        return Person(result,count)
    }
     */
}