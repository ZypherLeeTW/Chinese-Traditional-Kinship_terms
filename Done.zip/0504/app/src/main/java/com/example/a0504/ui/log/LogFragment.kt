package com.example.a0504.ui.log

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.a0504.databinding.FragmentLogBinding
import com.example.a0504.ui.add.MyDBHelper


class LogFragment : Fragment() {

    private var _binding: FragmentLogBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLogBinding.inflate(inflater, container, false)

        //db
        val DB_FILE = "Call.db"
        val DB_TABLE = "call"
        val MyDB: SQLiteDatabase
        // 建立自訂的 FriendDbHelper 物件
        val friDbHp = MyDBHelper(context, DB_FILE, null, 1)
        // 設定建立 table 的指令
        friDbHp.sCreateTableCommand = "CREATE TABLE " + DB_TABLE + "(" +
                "id INTEGER PRIMARY KEY," +
                "name TEXT NOT NULL," +
                "address TEXT)"
        // 取得上面指定的檔名資料庫，如果該檔名不存在就會自動建立一個資料庫檔案
        MyDB = friDbHp.writableDatabase
        fun dbSelect(){
            //查詢資料表
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("name", "address"),
                null, null, null, null, null, null
            )
            if (c.count === 0) {
                binding.textView1.text = ""
                Toast.makeText(context, "沒有資料", Toast.LENGTH_LONG).show()
            }
            else {
                c.moveToFirst();
                binding.textView1.text = "姓名\t稱呼"
                binding.textView1.append("\n" + c.getString(0) + "：" + c.getString(1))
                while (c.moveToNext()) {
                    binding.textView1.append("\n" + c.getString(0) + "：" + c.getString(1))
                }
            }
        }
        dbSelect()

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}