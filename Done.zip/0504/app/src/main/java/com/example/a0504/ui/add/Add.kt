package com.example.a0504.ui.add

import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.a0504.databinding.FragmentAddBinding


class Add : Fragment() {

    private var _binding: FragmentAddBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddBinding.inflate(inflater, container, false)
        //db
        val DB_FILE = "Call.db"
        val DB_TABLE = "call"
        var MyDB: SQLiteDatabase
        val friDbHp = MyDBHelper(context, DB_FILE, null, 1)
        friDbHp.sCreateTableCommand = "CREATE TABLE " + DB_TABLE + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "address TEXT)"
        MyDB = friDbHp.writableDatabase
        //清空輸入框
        binding.edName.text.clear()
        binding.edAddress.text.clear()

        fun dbSelect(){
            //查詢
            binding.btnQuery.setOnClickListener{
                MyDB = friDbHp.writableDatabase
                //查詢資料表
                val c = MyDB.query(
                    true, DB_TABLE, arrayOf("name", "address"),
                    null, null, null, null, null, null
                )
                if (c.count === 0) {
                    binding.textView1.text = ""
                    Toast.makeText(context, "沒有資料", Toast.LENGTH_LONG).show()
                }
                else {
                    c.moveToFirst();
                    binding.textView1.text = "姓名\t\t\t\t稱呼"
                    binding.textView1.append("\n" + c.getString(0) + "\t\t：" + c.getString(1))
                    while (c.moveToNext()) {
                        binding.textView1.append("\n" + c.getString(0) + "\t\t：" + c.getString(1))
                    }
                }
                //清空輸入框
                binding.edName.text.clear()
                binding.edAddress.text.clear()
            }
        }
        dbSelect()
        fun dbAdd(){
            //新增
            binding.btnAdd.setOnClickListener {
                MyDB = friDbHp.writableDatabase
                MyDB.execSQL("INSERT INTO "+DB_TABLE+"('name','address')"+" VALUES('"+binding.edName.text.toString()+"','"+binding.edAddress.text.toString()+"')")

                //清空輸入框
                binding.edName.text.clear()
                binding.edAddress.text.clear()
            }
        }
        dbAdd()
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}