package com.example.a0504.ui.add

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.a0504.databinding.FragmentAddBinding


class Add : Fragment() {

    private var _binding: FragmentAddBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddBinding.inflate(inflater, container, false)
        //db
        val DB_FILE = "Call.db"
        val DB_TABLE = "call"
        val MyDB: SQLiteDatabase
        // 建立自訂的 FriendDbHelper 物件
        val friDbHp = MyDBHelper(context, DB_FILE, null, 1)
        // 設定建立 table 的指令
        friDbHp.sCreateTableCommand = "CREATE TABLE " + DB_TABLE + "(" +
                "id INTEGER PRIMARY KEY," +
                "name TEXT NOT NULL," +
                "address TEXT)"
        // 取得上面指定的檔名資料庫，如果該檔名不存在就會自動建立一個資料庫檔案
        MyDB = friDbHp.writableDatabase

        //查詢
        binding.btnView.setOnClickListener{
            //查詢資料表
            val c = MyDB.query(
                true, DB_TABLE, arrayOf("name", "address"),
                null, null, null, null, null, null
            )
            if (c.count === 0) {
                binding.textView1.text = ""
                Toast.makeText(context, "沒有資料", Toast.LENGTH_LONG).show()
            }
            else {
                c.moveToFirst();
                binding.textView1.text = c.getString(0) + "\t" + c.getString(1)
                while (c.moveToNext()) {
                    binding.textView1.append("\n" + c.getString(0) + "\t" + c.getString(1))
                }
            }
        }

        //新增
        binding.btnAdd.setOnClickListener {
            // 宣告一ContentValues
            val newRow = ContentValues()
            // 將要新增的欄位"name","sex"與"address"，放入ContentValues中
            newRow.put("name", binding.edName.text.toString())
            newRow.put("address", binding.edAddress.text.toString())
            // 將ContentValues中的資料，放至資料表中
            MyDB.insert(DB_TABLE, null, newRow)
        }
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}