package com.example.a0504.ui.address

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.a0504.databinding.FragmentAddressBinding


@Suppress("DUPLICATE_LABEL_IN_WHEN")
class AddressFragment : Fragment() , OnClickListener{

    private var _binding: FragmentAddressBinding? = null
    private val binding get() = _binding!!
    //Declare
    private lateinit var btnclean:Button
    private lateinit var btnenter:Button
    private lateinit var text1:TextView
    private lateinit var show:TextView
    private var tin = arrayListOf<String>()
    private var bin:Int = 0
    //Main
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddressBinding.inflate(inflater, container, false)
        //Connect
        btnclean = binding.clean
        btnenter = binding.count
        text1 = binding.t1
        show = binding.tshow
        //Listener
        btnclean.setOnClickListener(fClean)
        btnenter.setOnClickListener(fEnter)
        //輩分按鈕
        binding.btn1.setOnClickListener(this)
        binding.btn2.setOnClickListener(this)
        binding.btn3.setOnClickListener(this)
        binding.btn4.setOnClickListener(this)
        binding.btn5.setOnClickListener(this)
        binding.btn6.setOnClickListener(this)
        binding.btn7.setOnClickListener(this)
        binding.btn8.setOnClickListener(this)
        binding.btn9.setOnClickListener(this)
        binding.btn10.setOnClickListener(this)
        binding.btn11.setOnClickListener(this)
        binding.btn12.setOnClickListener(this)

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private var fClean = OnClickListener {
        text1.text = ""
        show.text = ""
        tin.clear()
    }
    private var fEnter = OnClickListener {
        calculate()
    }

    override fun onClick(v: View?) {
        if (v != null) {
            when(v.id){
                binding.btn1.id -> tin += binding.btn1.text.toString()
                binding.btn2.id -> tin += binding.btn2.text.toString()
                binding.btn3.id -> tin += binding.btn3.text.toString()
                binding.btn4.id -> tin += binding.btn4.text.toString()
                binding.btn5.id -> tin += binding.btn5.text.toString()
                binding.btn6.id -> tin += binding.btn6.text.toString()
                binding.btn7.id -> tin += binding.btn7.text.toString()
                binding.btn8.id -> tin += binding.btn8.text.toString()
                binding.btn9.id -> tin += binding.btn9.text.toString()
                binding.btn10.id -> tin += binding.btn10.text.toString()
                binding.btn11.id -> tin += binding.btn11.text.toString()
                binding.btn12.id -> tin += binding.btn12.text.toString()
            }
            show(bin)
        }
    }
    //輩分計算
    private fun calculate(){
        //只有一個輸入，除錯
        if(tin.size != 1 ) {
            //text_in檢測，兩兩比較，比較完成取代後方
            for (j in 0 until tin.size - 1) {
                //第一個比較
                when (tin[j]) {
                    "爸爸" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "媽媽" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "兄弟" -> {
                                show.text = "舅叔"
                                tin[j + 1] = "舅叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "祖父" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin += 1
                            }
                            "丈夫" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "妻子" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "媽媽" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                            }
                            "兄弟" -> {
                                show.text = "舅舅"
                                tin[j + 1] = "舅舅"
                            }
                            "姊妹" -> {
                                show.text = "阿姨"
                                tin[j + 1] = "阿姨"
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 1
                            }
                            "丈夫" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "妻子" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "兄弟","姊妹" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "媽媽" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "兄弟" -> {
                                show.text = "兄弟"
                                tin[j + 1] = "兄弟"
                            }
                            "姊妹" -> {
                                show.text = "姊妹"
                                tin[j + 1] = "姊妹"
                            }
                            "祖父" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            "丈夫" -> {
                                when(tin[j + 1]){
                                    "兄弟" ->{
                                        show.text = "兄夫弟婿"
                                        tin[j + 1] = "兄夫弟婿"
                                    }
                                    "姊妹" -> {
                                        show.text = "姊夫妹夫"
                                        tin[j + 1] = "姊夫妹夫"
                                    }
                                }
                            }
                            "妻子" -> {
                                when(tin[j + 1]){
                                    "兄弟" ->{
                                        show.text = "兄嫂弟媳"
                                        tin[j + 1] = "兄嫂弟媳"
                                    }
                                    "姊妹" -> {
                                        show.text = "姊嫂妹媳"
                                        tin[j + 1] = "姊嫂妹媳"
                                    }
                                }
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "丈夫" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "公公"
                                tin[j + 1] = "公公"
                            }
                            "媽媽" -> {
                                show.text = "婆婆"
                                tin[j + 1] = "婆婆"
                            }
                            "兄弟" -> {
                                show.text = "伯叔"
                                tin[j + 1] = "伯叔"
                            }
                            "姊妹" -> {
                                show.text = "姑姑"
                                tin[j + 1] = "姑姑"
                            }
                            "丈夫","妻子" -> {
                                show.text = "自己"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "妻子" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "岳父"
                                tin[j + 1] = "岳父"
                            }
                            "媽媽" -> {
                                show.text = "岳母"
                                tin[j + 1] = "岳母"
                            }
                            "兄弟" -> {
                                show.text = "舅子"
                                tin[j + 1] = "舅子"
                            }
                            "姊妹" -> {
                                show.text = "姨子"
                                tin[j + 1] = "姨子"
                            }
                            "丈夫","妻子" -> {
                                show.text = "自己"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "祖父" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 1
                            }
                            "祖母" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                show.text = "伯叔公"
                                tin[j + 1] = "伯叔公"
                            }
                            "姊妹" -> {
                                show.text = "姑婆"
                                tin[j + 1] = "姑婆"
                            }
                            "爺爺" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                                bin += 2
                            }
                            "奶奶" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "妻子" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    "祖母" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                show.text = "舅公"
                                tin[j + 1] = "舅公"
                            }
                            "姊妹" -> {
                                show.text = "姨婆"
                                tin[j + 1] = "姨婆"
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 2
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "祖父"
                                tin[j + 1] = "祖父"
                            }
                            "妻子" -> {
                                show.text = "祖母"
                                tin[j + 1] = "祖母"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "外祖父","外祖母" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 1
                            }
                            "媽媽" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin =+ 1
                            }
                            "兄弟" -> {
                                when(tin[j + 1]){
                                    "外祖父" -> {
                                        show.text = "伯叔公"
                                        tin[j + 1] = "伯叔公"
                                    }
                                    "外祖母" ->{
                                        show.text = "舅公"
                                        tin[j + 1] = "舅公"
                                    }
                                }
                            }
                            "姊妹" -> {
                                when(tin[j + 1]){
                                    "外祖父" -> {
                                        show.text = "姑婆"
                                        tin[j + 1] = "姑婆"
                                    }
                                    "外祖母" ->{
                                        show.text = "姨公"
                                        tin[j + 1] = "姨公"
                                    }
                                }
                            }
                            "祖父" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                                bin += 2
                            }
                            "祖母" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                                bin += 2
                            }
                            "丈夫" -> {
                                show.text = "外祖父"
                                tin[j + 1] = "外祖父"
                            }
                            "妻子" -> {
                                show.text = "外祖母"
                                tin[j + 1] = "外祖母"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    //
                    "兒子","女兒" -> {
                        //第二個比較
                        when (tin[j + 1]) {
                            "爸爸","媽媽" -> {
                                show.text = "自己"
                                tin[j + 1] = "自己"
                            }
                            "兄弟" -> {
                                show.text = "兒子"
                                tin[j + 1] = "兒子"
                            }
                            "姊妹" -> {
                                show.text = "女兒"
                                tin[j + 1] = "女兒"
                            }
                            "祖父" -> {
                                show.text = "爸爸"
                                tin[j + 1] = "爸爸"
                            }
                            "祖母" -> {
                                show.text = "媽媽"
                                tin[j + 1] = "媽媽"
                            }
                            "丈夫" ->{
                                show.text = "女婿"
                                tin[j + 1] = "女婿"
                            }
                            "妻子" -> {
                                show.text = "兒媳"
                                tin[j + 1] = "兒媳"
                            }
                            else -> {
                                show.text = "超出計算"
                            }
                        }
                    }
                    else -> {
                        show.text = "超出計算"
                    }
                }
            }
        }else{
            show.text = tin[0]
        }
        tin.clear()//清空判別
        show(bin)
    }
    private fun show(bin:Int){
        //清除站存列
        text1.text = ""
        //超級加輩
        if (bin != 0){
            for(k in 1 .. bin){
                show.text = "曾".plus(show.text)
            }
        }
        this.bin = 0
        //除錯空陣列
        if (tin.size != 0){
            text1.text = tin[0]
            //除錯小於1陣列
            if (tin.size > 1){
                for (i in 1 until tin.size){
                    text1.text = text1.text.toString().plus(" 的 ").plus(tin[i])
                }
            }else{
                //tin = 1
            }
        }else{
            //空陣列Do nothing
        }
    }
}